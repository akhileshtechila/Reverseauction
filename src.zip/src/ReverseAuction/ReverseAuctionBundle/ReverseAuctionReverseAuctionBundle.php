<?php

namespace ReverseAuction\ReverseAuctionBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class ReverseAuctionReverseAuctionBundle extends Bundle
{
}
