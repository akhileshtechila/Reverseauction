<?php

namespace ReverseAuction\WebservicesBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class ReverseAuctionWebservicesBundle extends Bundle
{
}
